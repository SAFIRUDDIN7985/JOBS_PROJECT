import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Job } from '../model/job.model';
import { JobService } from '../service/job.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  jobs:Job[];

  constructor(private jobService:JobService,private router:Router) { }

  addFavouriteJob(job){
    alert("Job is going to be added")
    this.jobService.saveFavouriteJobs(job).subscribe(
      data=>{
        console.log("Response Added",data);
        this.jobs=job;
        this.router.navigate(['/viewFavouriteJob']);
        
      },

      error=>{
        console.log("Exception Occured");
      }
    )
  }


  ngOnInit() {
  }

}
