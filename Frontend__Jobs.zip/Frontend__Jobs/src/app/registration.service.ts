import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  constructor(private _http:HttpClient) { }


public loginUserFormRemote(user:User):Observable<any>{

    return this._http.post<any>("http://localhost:8080/api/v2/login",user);

}

public registerUserFromRemote(user:User):Observable<any>{
  return this._http.post<any>("http://localhost:8080/api/v2/registeruser",user);
}




}
