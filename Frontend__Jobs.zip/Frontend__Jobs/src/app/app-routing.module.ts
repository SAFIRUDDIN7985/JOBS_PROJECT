import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { JobsComponent } from './jobs/jobs.component';
import { LoginComponent } from './login/login.component';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { RegistrationComponent } from './registration/registration.component';
import { ViewfavouriteComponent } from './viewfavourite/viewfavourite.component';
import { CreateJobsComponent } from './create-jobs/create-jobs.component';
import { SearchComponent } from './search/search.component';

const routes: Routes = [
  {path:"home",component:HomeComponent},
  { path:"loginsuccess",component:LoginsuccessComponent},
  {path:"login",component:LoginComponent},
  {path:"registration",component:RegistrationComponent},
  {path:"backToLoginPage",component:LoginComponent},
  {path:"", redirectTo:"home",pathMatch:"full"},
  {path:"goToJob",component:JobsComponent},
  {path:"createJobs",component:CreateJobsComponent},
  {path:"viewFavouriteJob",component:ViewfavouriteComponent},
  {path:"createJobsFoms",component:CreateJobsComponent},
  {path:"searchJobs",component:SearchComponent}
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
