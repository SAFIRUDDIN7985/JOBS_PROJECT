import { Component, OnInit } from '@angular/core';
import * as $ from "jquery";
import { NgForm } from '@angular/forms';
import { RegistrationService } from '../registration.service';
import { User } from '../user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user=new User();
  msg='';

  constructor(private _service:RegistrationService,private _router:Router) { }


  ngOnInit() {
  }

  loginUser(){

    this._service.loginUserFormRemote(this.user).subscribe(
      data=>{
        console.log("Response Done",data);
        alert("Login Successfully")
        this._router.navigate(['/loginsuccess']);
      },
      error=>{
        console.log("Exception Occured");
        alert("Please provide the correct credentials")
         this.msg="Bad credential, Please enter valid email Id and password";
        
        }  
    );
  }
  goToRegistration(){
    this._router.navigate(['/registration']);
  }
  
  // testing(){
  //   var name=$("#txtName").val();
  //   alert(name);
  // }

}
