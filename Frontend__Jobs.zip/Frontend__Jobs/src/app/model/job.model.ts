export class Job{

    jobId:number;
    companyName:string;
    profile:string;
    skillRequired:string;
    experience:number

}