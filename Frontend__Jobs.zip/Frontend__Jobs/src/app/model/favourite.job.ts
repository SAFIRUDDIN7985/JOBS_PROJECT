export class FavouriteJobs{
    jobId:number;
    companyName:string;
    profile:string;
    skillRequired:string;
    experience:number

}