import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Job } from '../model/job.model';
import { JobService } from '../service/job.service';

@Component({
  selector: 'app-create-jobs',
  templateUrl: './create-jobs.component.html',
  styleUrls: ['./create-jobs.component.css']
})
export class CreateJobsComponent implements OnInit {

  jobs=new Job();

  constructor(private service:JobService,private router:Router) { }

  addingJobs(){
    this.service.jobRegistrationForms(this.jobs).subscribe(
      data=>{
        console.log("Forms data recieved successfully",data);
        this.router.navigate(['/goToJob']);
        
        alert("Forms Added")
      },
      error=>{
        console.log("Exception Occured",error);
      }
    )
  }

  ngOnInit() {
  }

}
