import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewfavouriteComponent } from './viewfavourite.component';

describe('ViewfavouriteComponent', () => {
  let component: ViewfavouriteComponent;
  let fixture: ComponentFixture<ViewfavouriteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewfavouriteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewfavouriteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
