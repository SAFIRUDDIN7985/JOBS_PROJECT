import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JobService } from '../service/job.service';
import {Job} from '../model/job.model'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-viewfavourite',
  templateUrl: './viewfavourite.component.html',
  styleUrls: ['./viewfavourite.component.css']
})
export class ViewfavouriteComponent implements OnInit {
  jobs:Job[];
  // id:number;
  constructor(private jobService:JobService,private httpClient:HttpClient,private router:Router,private http:HttpClient) { }


  seeTheFavouriteJobs(){
    this.jobService.getAllTheFavouriteJobs().subscribe(
      response=>{
        console.log("Response Done",response);
        this.jobs=response;
      },
      error=>{
        console.log("Exception has been Occured")
      }
    )
  }

  
  deleteFavouriteJobById(id:number){
   
    
    this.jobService.deleteFavouriteJobsById(id).subscribe(
      response=>{
        alert("This info going to be deleted");
        console.log("Deleted Successfully",response); 
        this.jobs=this.jobs.filter(item=>item.jobId!==id);
        location.reload();
      },
      error=>{ 
        console.log("Exception Occured While Deleting",error);
      }
    )

    return this.jobs;
  }

  
  ngOnInit() {
    this.seeTheFavouriteJobs();
    // this.deleteFavouriteJobById(this.id)
    
  }



}

  