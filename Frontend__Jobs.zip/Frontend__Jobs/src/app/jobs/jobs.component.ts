import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Job } from '../model/job.model';
import { JobService } from '../service/job.service';


@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.css']
})
export class JobsComponent implements OnInit {

  jobs:Job[];
 
  
  constructor(private jobService:JobService,private router:Router, private httpClient:HttpClient) { }


  seeListOfJobs() {

    this.jobService.getAllListJobs().subscribe(
      data=>{
        console.log("Response Successfull",data);
        // alert("Done")
        this.jobs=data;
      },
      error=>{
        alert("Exception has been Occured ")
        console.log("Exception Occured");
      }
    )
  }

 
  addFavouriteJob(job){
    alert("Job is going to be added")
    this.jobService.saveFavouriteJobs(job).subscribe(
      data=>{
        console.log("Response Added",data);
        this.jobs=job;
        this.router.navigate(['/viewFavouriteJob']);
        
      },

      error=>{
        console.log("Exception Occured");
      }
    )
  }

  searchFunction(){
  
   const filter=(<HTMLInputElement>document.getElementById('myInput')).value.toUpperCase();
  //  this.router.navigate(['/searchJobs']);
   const myTable=document.getElementById('myTable');
   const tr=myTable.getElementsByTagName('tr');
   for(var i=0;i<tr.length;i++){
     const td=tr[i].getElementsByTagName('td')[1];
     if(td){
       const textValue=td.textContent || td.innerHTML
       if(textValue.toUpperCase().indexOf(filter)>-1){
         tr[i].style.display="";
       }else{
         tr[i].style.display="None"
       }
     }
   }
   
  
  
  }


  ngOnInit() {
 
        this.seeListOfJobs();
        this.searchFunction();

  }

}







