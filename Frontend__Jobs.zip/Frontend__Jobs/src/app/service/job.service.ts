import { Injectable } from '@angular/core';
import {FavouriteJobs} from 'src/app/model/favourite.job'
import { Job } from 'src/app/model/job.model'
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class JobService {

  constructor(private http:HttpClient) { }

  public getAllListJobs():Observable<any>{
    return this.http.get<any>("http://localhost:8002/job/jobLists/");
  }

  public getAllTheFavouriteJobs():Observable<any>{
    return this.http.get<any>('http://localhost:8001/addFavouriteJob/findAllJob');
  }

  
  public deleteFavouriteJobsById(id:number):Observable<any>{
    
    return this.http.delete('http://localhost:8001/addFavouriteJob/deleteFavourite/'+id);
  }

  public saveFavouriteJobs(job:Job):Observable<any>{
  
    return this.http.post("http://localhost:8001/addFavouriteJob/save",job);
  }

  public getFavouriteJobById(id:number):Observable<any>{
    return this.http.get('http://localhost:8001/addFavouriteJob/find/'+id);
  }
  
  public jobRegistrationForms(job:Job):Observable<any>{
    return this.http.post('http://localhost:8002/job/save',job);
  }

  public getJobsByProfiles(profile:string):Observable<any>{
    return this.http.get('http://localhost:8002/job/find/'+profile);
  }
 
}
